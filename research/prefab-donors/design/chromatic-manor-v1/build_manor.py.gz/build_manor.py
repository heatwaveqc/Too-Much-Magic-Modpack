#!/usr/bin/env python3
"""Original TMM Chromatic Manor, QA only; Python standard library."""
import collections,gzip,hashlib,io,json,math,pathlib,struct
O=pathlib.Path(__file__).parent; W,H,D=65,51,61; B={}; A='minecraft:air'
def put(x,y,z,n,**p):
 assert 0<=x<W and 0<=y<H and 0<=z<D,(x,y,z,n)
 B[x,y,z]=(n if ':' in n else 'minecraft:'+n,tuple(sorted((k,str(v).lower()) for k,v in p.items())))
def box(x1,x2,y1,y2,z1,z2,n,**p):
 for y in range(y1,y2+1):
  for z in range(z1,z2+1):
   for x in range(x1,x2+1):put(x,y,z,n,**p)
G=16; U=27; C='calcite'; T='white_terracotta'; S='spruce_planks'; R='dark_oak_planks'; P='polished_andesite'; GLA='purple_stained_glass'; AIR='air'
# Landscaped surface. Avoid writing air outside the property or below the defined subterranean works.
box(2,62,15,15,2,58,'grass_block',snowy=False)
box(7,57,16,16,7,43,P); box(8,56,16,16,8,42,S)
box(7,57,27,27,7,43,P); box(8,56,27,27,8,42,S)
box(8,56,17,26,8,42,AIR);box(8,56,28,36,8,42,AIR)
# Gabled manor: layered white trim, paneled warm roofs, luminous purple windows (vanilla glass + lanterns).
for y in range(16,37):
 for x in range(7,58):
  for z in range(7,44):
   if x not in (7,57) and z not in (7,43):continue
   pier=(x-7)%6==0 if z in (7,43) else (z-7)%6==0
   f=16 if y<27 else 27; dy=y-f
   n= C if pier or dy in (0,1,9) or y in (26,36) else T
   if not pier and 3<=dy<=7 and ((x-7)%6 in (2,3,4) if z in (7,43) else (z-7)%6 in (2,3,4)):
    n=GLA
   put(x,y,z,n)
# Continuous roof, three cross-gables facing front; overlapping roof volumes joined by max height.
for z in range(6,45):
 for x in range(6,59):
  main=37+max(0,9-abs(z-25)//2)
  wing=max([37+max(0,9-abs(x-c)) for c in (16,32,48)]) if z>=25 else 37
  y=max(main,wing);put(x,y,z,R)
  if x in (6,58) or z in (6,44):
   for k in range(37,y):put(x,k,z,C if k in (37,y-1) else T)
  # seal step between adjacent roof heights, use wood face
  for xx,zz in ((x-1,z),(x,z-1)):
   if xx<6 or zz<6:continue
   m=37+max(0,9-abs(zz-25)//2); v=max([37+max(0,9-abs(xx-c)) for c in (16,32,48)]) if zz>=25 else 37
   prev=max(m,v)
   if prev<y:
    for k in range(prev+1,y):put(x,k,z,R)
   elif y<prev:
    for k in range(y+1,prev):put(xx,k,zz,R)
# Gable trim at southern facade; entry porch and accessible steps.
for c in (16,32,48):
 for dx in range(-8,9):put(c+dx,37+9-abs(dx),44,C)
for x in (31,32):
 for z in (43,):
  for dy,half in [(1,'lower'),(2,'upper')]:put(x,G+dy,z,'spruce_door',facing='south',half=half,hinge='left' if x==31 else 'right',open=False,powered=False)
for x in range(29,35):
 for z in range(44,47):put(x,16,z,P)
box(29,34,15,15,47,57,'stone_bricks')
for x in (31,32):put(x,16,47,'stone_brick_stairs',facing='north',half='bottom',shape='straight',waterlogged=False)
for x in (29,34):
 box(x,x,17,20,46,46,C)
box(28,35,21,21,43,47,R)
# Room divisions stop at corridors. No walls in reserved multiblock envelopes.
# Ground west hall x9..25 z9..25, east living / pigment, rear circulation.
for y in range(17,26):
 for z in range(8,28):
  if z not in (18,19,20) or y>19:put(26,y,z,C)
 for x in range(8,27):
  if x not in (18,19,20) or y>19:put(x,y,27,C)
# Upper enchanter x40..54 z9..23, instiller x10..21 z9..21; central corridor.
for y in range(28,37):
 for x,zs in [(23,range(8,24)),(38,range(8,26))]:
  for z in zs:
   if z not in (18,19,20) or y>30:put(x,y,z,C)
 for z,xx in [(23,range(8,24)),(25,range(39,57))]:
  for x in xx:
   if x not in (16,17,18,46,47,48) or y>30:put(x,y,z,C)
# Upstairs staircase, two wide, rises north. Lower passage at south, landing north.
def stair(x,y,z,f):put(x,y,z,'spruce_stairs',facing=f,half='bottom',shape='straight',waterlogged=False)
for j in range(11):
 z=23-j;y=17+j
 for x in (30,31):
  for k in range(y+1,min(y+4,37)):put(x,k,z,AIR)
  stair(x,y,z,'north')
# Clear opening in upper floor only where necessary, preserve top tread.
for x in (30,31):
 for z in range(14,20):
  if B.get((x,U,z),(A,))[0]!='minecraft:spruce_stairs':put(x,U,z,AIR)
# rails at upper stair opening, no obstruction to entries.
for x in (29,32):
 for z in range(14,21):put(x,28,z,'spruce_fence',east=False,west=False,north=True,south=True,waterlogged=False)
# Five dedicated machine envelopes, floor borders colored, no components inside.
rooms={'pedestal':(9,25,17,25,9,25),'enchanter':(40,54,28,34,9,23),'spirit_instiller':(10,21,28,34,9,21),'fusion_shrine':(7,19,17,23,46,58),'cinderhearth':(54,61,17,23,46,54)}
for name,(a,b,lo,hi,c,d) in rooms.items():
 color={'pedestal':'magenta','enchanter':'purple','spirit_instiller':'cyan','fusion_shrine':'light_blue','cinderhearth':'orange'}[name]
 for x in range(a,b+1):
  for z in range(c,d+1):
   put(x,lo-1,z,color+'_terracotta' if x in (a,b) or z in (c,d) else P)
   if name in ('fusion_shrine','cinderhearth'):box(x,x,lo,hi,z,z,AIR) # reserve actual clear volume
# Solid subfloor under each exterior machine, plus level paths and garden access.
for a,b,c,d in [(7,19,46,58),(54,61,46,54)]:box(a,b,15,15,c,d,'cobblestone')
for z in range(46,59):
 for x in range(20,54):
  if (x in (20,21,52,53) or z in (46,57)) and not 29<=x<=34:put(x,15,z,'stone_bricks')
# Starter stations and rooms, placed outside every reserved volume.
for x,n in [(42,'pastel:pedestal_basic_topaz'),(45,'pastel:pedestal_basic_amethyst'),(48,'pastel:pedestal_basic_citrine'),(51,'anvil')]:put(x,17,34,n,**({'facing':'north'} if n=='anvil' else {}))
for x in (40,53):put(x,17,32,'crafting_table')
for x in (40,42,44,46,48,50,52,54):put(x,17,37,'barrel',facing='up',open=False)
for x in (42,46,50,54):put(x,17,26,'bookshelf')
for x in (10,14):
 for z,part in [(39,'head'),(40,'foot')]:put(x,17,z,'purple_bed',facing='north',part=part,occupied=False)
for x,n in [(17,'crafting_table'),(18,'furnace'),(19,'smoker'),(20,'barrel')]:put(x,17,40,n)
for x in (10,12,14,16,18,20):put(x,28,37,'barrel',facing='up',open=False)
# Future standalone stations: empty bays marked with one tile, never actual gated machine.
for x,z in [(42,29),(46,29),(50,29),(54,29),(42,38),(46,38),(50,38),(54,38)]:put(x,27,z,'light_blue_terracotta')
# Lights on ceilings outside clearance volumes; windows are decorative, add lanterns along circulation.
for y in (26,36):
 for x in (11,19,27,34,42,50):
  for z in (12,21,31,39):
   if y==36:put(x,37,z,'spruce_planks')
   if not any(a<=x<=b and c<=z<=d and lo<=y<=hi for a,b,lo,hi,c,d in rooms.values()):put(x,y,z,'lantern',hanging=True,waterlogged=False)
# Flower gardens: raised beds and plentiful ordinary dye sources, no progression-gated plants.
flowers=['allium','cornflower','dandelion','poppy','pink_tulip','orange_tulip','white_tulip','azure_bluet','blue_orchid','oxeye_daisy','lily_of_the_valley','red_tulip']
for a,b,c,d in [(23,27,49,55),(37,41,49,55),(45,49,49,55),(3,5,9,40),(59,61,9,40)]:
 for z in range(c,d+1):
  for x in range(a,b+1):
   put(x,15,z,'grass_block',snowy=False)
   if (x+z)%2==0:put(x,16,z,flowers[(x+3*z)%len(flowers)])
for z in (10,16,22,28,34,40):
 for x in (6,58):
  put(x,16,z,'spruce_leaves',persistent=True,distance=1,waterlogged=False)
  put(x,17,z,'spruce_leaves',persistent=True,distance=1,waterlogged=False)
# Basement: hollow naturalistic ellipsoid, basalt outside, calcite middle, amethyst lining.
for y in range(0,16):
 for z in range(12,38):
  for x in range(15,45):
   q=math.sqrt(((x-30)/13)**2+((y-8)/7.5)**2+((z-25)/11.5)**2)
   if q<=1:put(x,y,z,'smooth_basalt' if q>=.87 else 'calcite' if q>=.75 else 'amethyst_block' if q>=.62 else AIR)
# Level walking floor cavern; smaller amethyst alcoves remain visible.
for z in range(19,32):
 for x in range(24,37):
  if ((x-30)/8)**2+((z-25)/8)**2<=1:
   put(x,4,z,'amethyst_block');box(x,x,5,7,z,z,AIR)
# Separate Hex practice laboratory (natural stone); no Hex advanced items.
box(43,55,3,12,19,35,'stone_bricks');box(44,54,4,4,20,34,P);box(44,54,5,11,20,34,AIR)
box(36,44,5,8,24,26,AIR);box(36,44,4,4,24,26,P)
for z in (21,33):
 for x in (45,49,53):put(x,5,z,'barrel',facing='up',open=False)
put(45,5,23,'crafting_table');put(54,5,23,'bookshelf')
for x in (46,52):
 for z in (23,30):put(x,11,z,'lantern',hanging=True,waterlogged=False)
# Basement stairs descend north from main entry rear; carve headroom, land on cavern floor at z=28.
for j in range(12):
 y=5+j;z=29+j
 for x in (34,35):
  if y<=15:box(x,x,y, min(y+3,26),z,z,AIR)
  else:box(x,x,y+1,min(y+3,26),z,z,AIR)
  stair(x,y,z,'south')
for x in (33,36):
 for z in range(37,41):put(x,17,z,'spruce_fence',east=False,west=False,north=True,south=True,waterlogged=False)
# Place 12 budding blocks on accessible shell faces; no ore/charged amethyst. Candidate x/z sorted.
ns=[(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]
candidates=[]
for (x,y,z),v in list(B.items()):
 if v[0]!='minecraft:amethyst_block' or y<5 or y>11 or x>=36:continue
 if any(B.get((x+dx,y+dy,z+dz),('void',))[0]==A for dx,dy,dz in ns):candidates.append((x,y,z))
chosen=[]
for p in sorted(candidates,key=lambda p:(p[0]*17+p[1]*31+p[2]*13)%97):
 if all(sum(abs(a-b) for a,b in zip(p,q))>=3 for q in chosen):
  chosen.append(p);put(*p,'budding_amethyst')
  if len(chosen)==12:break
assert len(chosen)==12
# Visible cavern lighting on walkable platform perimeter (not in walkway).
for x,z in [(25,23),(25,27),(30,19),(30,31)]:put(x,5,z,'lantern',hanging=False,waterlogged=False)
# Verify all intended air envelopes against final voxel state; explicit air or omitted exterior.
for name,(a,b,lo,hi,c,d) in rooms.items():
 for x in range(a,b+1):
  for y in range(lo,hi+1):
   for z in range(c,d+1):assert B.get((x,y,z),(A,))[0]==A,(name,x,y,z,B.get((x,y,z)))
# standard vanilla StructureTemplate encoding, no entity/inventory payloads.
PALS=sorted(set(B.values())); IDS={p:i for i,p in enumerate(PALS)}; pack=lambda f,*v:struct.pack('>'+f,*v)
def st(s):b=s.encode();return pack('H',len(b))+b
def cp(d):return b''.join(pack('B',t)+st(k)+v for k,(t,v) in d.items())+b'\0'
def li(t,a):return pack('Bi',t,len(a))+b''.join(a)
def ints(a):return li(3,[pack('i',v) for v in a])
pal=[cp({'Name':(8,st(n)),**({'Properties':(10,cp({k:(8,st(v)) for k,v in p}))} if p else {})}) for n,p in PALS]
entries=[cp({'pos':(9,ints([x,y,z])),'state':(3,pack('i',IDS[v]))}) for (x,y,z),v in sorted(B.items(),key=lambda a:(a[0][1],a[0][2],a[0][0]))]
raw=b'\x0a\x00\x00'+cp({'DataVersion':(3,pack('i',3955)),'size':(9,ints([W,H,D])),'palette':(9,li(10,pal)),'blocks':(9,li(10,entries)),'entities':(9,li(10,[]))})
f=O/'prefab-extension'/'chromatic_manor.nbt';f.parent.mkdir(exist_ok=True);f.write_bytes(gzip.compress(raw,mtime=0)); counts=collections.Counter(n for n,p in B.values()); sha=hashlib.sha256(f.read_bytes()).hexdigest()
audit={'status':'STATIC_QA_PREVIEW_ONLY','size':[W,H,D],'ground_anchor_y':G,'nonair':len(B)-counts[A],'explicit_air':counts[A],'palette_states':len(PALS),'sha256':sha,'nbt_bytes':f.stat().st_size,'rooms':rooms,'budding_positions':chosen,'material_counts':dict(counts),'generator_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()};(O/'audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps({k:v for k,v in audit.items() if k not in ('material_counts','budding_positions')},indent=2))
